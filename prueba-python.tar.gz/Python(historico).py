import sys, time, textwrap, contextlib
import numpy as np
import pandas as pd

##########################################################################################################
sys.exit()

#-------------------------------------------------
#Decorators

#Decorador @contextlib.contextmanager junto con un generador para crear un administrador de contexto llamado timer.
# Este administrador de contexto mide el tiempo que tarda en ejecutarse el bloque de código dentro de with timer()
@contextlib.contextmanager
def timer():
  start = time.time()
  # Send control back to the context block
  try:
    yield   # (acá es donde se corre lo que se pone luego de la llamada del with.)
  finally:
    end = time.time()
    print('Elapsed: {:.2f}s'.format(end - start))

with timer():
  print('This should take approximately 0.25 seconds')
  time.sleep(0.25)

#otro ejeplos de decoradores.

def print_return_type(func):
  # Define wrapper(), the decorated function
  def wrapper(*args, **kwargs):
    # Call the function being decorated
    result = func(*args, **kwargs)
    print('{}() returned type {}'.format(
      func.__name__, type(result)
    ))
    return result
  # Return the decorated function
  return wrapper
  
@print_return_type
def foo(value):
  return value

# print(foo(42))
# print(foo([1, 2, 3]))
# print(foo({'a': 42}))


#-------------------------------------------------
#Tokens
import nltk
from nltk.tokenize import word_tokenize
from collections import Counter

#nltk.download('punkt')  # Descarga el modelo de tokenización de palabras

def tokenize(text):
    # Utiliza la tokenización de palabras de nltk
    tokens = word_tokenize(text)
    return tokens

# Ejemplo de uso
datacamp_tweets = 'Muuuucho texto loco de tweet 222'
tokens = tokenize(datacamp_tweets)

# print(tokens)

# Utiliza Counter para contar la frecuencia de cada token
token_frequencies = Counter(tokens)

# Imprime las frecuencias de cada token
# for token, frequency in token_frequencies.items():
#     print(f"{token}: {frequency}")

#--------------------------------------------------------------------------------------------------
def contieneString(text1, text2):
  """ 
  recorre el text1 y devuelve true si el text2 esta contenido en el.

  :param text1: texto evaluar si contiene text2
  :param text2: texto a evaluar si está contenido en text2
  :return: true o false
  >>> contieneString('the rain in spain', 'in spain')
  True
 """
  
  contieneSTR = False
  contieneSTR = text1.find(text2) != -1
  
  #for i in range(0, len(text1)):
  #  contieneSTR = contieneSTR or text1.startswith(text2, i)

  #for i in range(0, len(text1)):
  #  if i+len(text2) < len(text1): contieneSTR = contieneSTR or (text1[i:i+len(text2)] == text2)
  
  #for i in range(0, len(text1)):
  #  coincidenSTRs = True
  #  for j in range(0, len(text2)):
  #    coincidenSTRs = coincidenSTRs and (text1[i+j] == text2[j])
  #  contieneSTR = contieneSTR or coincidenSTRs
  
  return contieneSTR

str1 = 'aHola como te v fsdfsdf te vad lskdg'
str2 = 'te va'

#print(contieneString(str1, str2))


#--------------------------------------------------------------------------------------------------
def difcajas(cajas):

  """
    calcula ajustes que hay que aplicar para que la matriz quede pareja

  :param cajas: array con cantidad de cajas en cada columna
  :return: array que retorna los austes que hay que hacer en cada columna

  >>> difcajas([6,2,5,6,1,4])
  [(1, -2), (2, 2), (3, -1), (4, -2), (5, 3), (6, 0)]
  """  
    
  cajas = [6,2,5,6,1,4]
  tamcol = int(sum(cajas)/len(cajas))
    
  return [(i+1, tamcol-cajas[i]) for i in range(0, len(cajas))]

cajas = [6,2,5,6,1,4]

# print(cajas)
# print(difcajas(cajas))

#--------------------------------------------------------------------------------------------------
# Ejercicios de Mutantes de Meli ------------------------------------------------------------------
def isMutant(dna):
  dnaBase = ["AAAA", "TTTT", "CCCC", "GGGG"]
  
  #Horizontal cases
  posibleValues = dna

  #Vertical cases
  vertical = []
  for i in range(len(dna)):
    vertical.append(''.join(list(x[i] for x in dna)))

  posibleValues = posibleValues + vertical

  #diagonal cases
  diagonal = []
  for i in range(len(dna)):
    diagonalIt1 = ""
    diagonalIt2 = ""
    diagonalIt3 = ""
    diagonalIt4 = ""
    for j in range(i, len(dna)):
      diagonalIt1 = diagonalIt1 + dna[j-i][j]
      diagonalIt2 = diagonalIt2 + dna[len(dna)-1-(j-i)][j]
      diagonalIt3 = diagonalIt3 + dna[j][j-i]
      diagonalIt4 = diagonalIt4 + dna[len(dna)-1-(j)][j-i]
    diagonal = diagonal + [diagonalIt1] + [diagonalIt2] + [diagonalIt3] + [diagonalIt4]

#  print(diagonal)
  posibleValues = posibleValues + diagonal
  
  #saco duplicados!
  posibleValues = list(set(posibleValues))

#  print(posibleValues)

  result = list(x for x in posibleValues for y in dnaBase if not x.find(y))
  print(result)

  return len(result) > 0


dnaNP = [
"ATGCGA",
"CAGTGC",
"TTATGT",
"AGAATG",
"CCCTTA",
"TCTCTG"
]


dnaNP = [
"ATGCGA",
"CAGTGC",
"TTATGT",
"AGAAGG",
"CCCCTA",
"TCACTG"
]

#print(isMutant(dnaNP))

#--------------------------------------------------------------------------------------------------
#Ejercicio Meli: encontrar los pares de con mínima distancia

def minDistPairs(input):

  input.sort()
  print(input)

  difMinima = input[1]-input[0]
  listaResult = [[input[1], input[0]]]

  for i in range(1, len(input)-1):
    difTmp = input[i+1]-input[i]
    if difTmp == difMinima:
      listaResult.append([input[i+1], input[i]])
    elif difTmp < difMinima:
      difMinima = difTmp
      listaResult = [[input[i+1], input[i]]]
  
  return (difMinima, listaResult)

input = [8, 30, 2, 20, 10, 5, 15, 21, 31]

#print(minDistPairs(input))

#--------------------------------------------------------------------------------------------------
# Cosas de NP arrays ------------------------------------------------------------------------------

a1d = np.arange(1, 7, 2)
a2d = np.array([[1, 2, 3],[1, 3, 4]])
aEmp = np.empty(4)
#a2 = a[np.newaxis, :]
# print(a2d.shape)
# print(a2d)
# print(a2d[0:,1:3])
# print(aEmp)
# print(a1d)

x = np.array([[1, 2], [3, 4]])
y = np.array([[5, 6], [7, 6]])
#print(np.concatenate((x, y), axis=1).reshape(4,2))

x = np.array([1, 2, 3, 4])
x2 = x[:, np.newaxis]
#x2 = x.reshape(4, 1)
#print(x2.shape)
#print(x2)

a1 = np.array([[1, 1],[2, 2]])
a2 = np.array([[3, 3],[4, 4]])
#print(np.vstack((a1, a2)))
#print(np.concatenate((a1, a2), axis=0))


#---------------------------------------------------------------------------------------------------------------
'''
if __name__ == '__main__':
  
  n = int(5)
  arr = list(map(int, "2 3 6 6 5".split()))

  arrunique = list(set(arr))
  arrunique.append(3)
  print(arrunique)
  arrunique.remove(max(arrunique))
  print(max(arrunique))
'''

listSN = []
scores = []

name = "Harry"
score = 37.21
listSN.append([name, score])
scores.append(score)
        
name = "Berry"
score = 37.2
listSN.append([name, score])
scores.append(score)

minscoreUNQ = list(set(scores))
minscoreUNQ.remove(min(minscoreUNQ))
secondScore = min(minscoreUNQ)

namesresult = []
for item in listSN:
    if item[1] == secondScore:
        namesresult.append(item[0])

# namesresult.sort()
# for item in namesresult:
#     print(item)


student_marks = {}
student_marks["Carlos"] = [20, 30, 70]
student_marks["Pedro"] = [20, 30, 100]

number = sum(student_marks["Carlos"])/len(student_marks["Carlos"])
#print(f'{number:1.2f}')

#---------------------------------------------------------------------------------------------------------------
string = "ABCDEFGHIJKLIMNOQRSTUVWXYZ"

word_list = textwrap.wrap(text=string, width=4)
# print(word_list)
# print("\n".join(word_list))
# print(*word_list, sep="\n")
